// Parent Process (write_message.c)
#include <stdio.h>
#include <stdlib.h>
#include <unistd.h>
#include <fcntl.h>
#include <sys/stat.h>

int main()
{
    const char *pipe_name = "my_fifo";
    const char *message = "Hello from Parent!";

    mkfifo(pipe_name, 0666); // Create a named pipe (FIFO)

    int fd = open(pipe_name, O_WRONLY);
    write(fd, message, sizeof(message));
    close(fd);

    printf("Parent: Sent message to child.\n");

    return 0;
}
