#include <stdio.h>
#include <stdlib.h>
#include <unistd.h>
#include <sys/types.h>
#include <sys/wait.h>

int main()
{
    pid_t child_pid;

    // Create a child process
    child_pid = fork();

    if (child_pid == -1)
    {
        perror("fork");
        exit(EXIT_FAILURE);
    }

    if (child_pid == 0)
    {
        // This is the child process
        printf("Child process: My PID is %d\n", getpid());
        // Sleep for 2 seconds
        sleep(2);
        printf("Child process: Exiting...\n");
        exit(EXIT_SUCCESS);
    }
    else
    {
        // This is the parent process
        printf("Parent process: My PID is %d\n", getpid());
        printf("Parent process: Waiting for the child to exit...\n");

        int status;
        pid_t terminated_pid = wait(&status);

        if (terminated_pid == -1)
        {
            perror("wait");
            exit(EXIT_FAILURE);
        }

        if (WIFEXITED(status))
        {
            printf("Parent process: Child process with PID %d exited normally with status: %d\n",
                   terminated_pid, WEXITSTATUS(status));
        }
        else if (WIFSIGNALED(status))
        {
            printf("Parent process: Child process with PID %d terminated by signal %d\n",
                   terminated_pid, WTERMSIG(status));
        }
    }

    return 0;
}
// output
/*
Parent process: My PID is 269
Parent process: Waiting for the child to exit...
Child process: My PID is 273
Child process: Exiting...
Parent process: Child process with PID 273 exited normally with status: 0
*/