// Child Process (read_message.c)
#include <stdio.h>
#include <stdlib.h>
#include <unistd.h>
#include <fcntl.h>
#include <sys/stat.h>

int main()
{
    const char *pipe_name = "my_fifo";
    char buffer[256];

    int fd = open(pipe_name, O_RDONLY);
    read(fd, buffer, sizeof(buffer));
    close(fd);

    printf("Child: Received message from parent: %s\n", buffer);

    return 0;
}
/*
Child: Received message from parent
*/
