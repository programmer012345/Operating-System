// Process A (process_a.c)
#include <stdio.h>
#include <stdlib.h>
#include <unistd.h>
#include <fcntl.h>
#include <sys/stat.h>

int main()
{
    const char *pipe_name = "my_fifo";
    const char *message = "Hello from Process A!";

    mkfifo(pipe_name, 0666); // Create a named pipe (FIFO)

    int fd = open(pipe_name, O_WRONLY);
    write(fd, message, sizeof(message));
    close(fd);

    printf("Process A: Sent message to Process B.\n");

    return 0;
}
