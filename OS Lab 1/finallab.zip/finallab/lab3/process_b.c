// Process B (process_b.c)
#include <stdio.h>
#include <stdlib.h>
#include <unistd.h>
#include <fcntl.h>
#include <sys/stat.h>

int main()
{
    const char *pipe_name = "my_fifo";
    char buffer[256];

    int fd = open(pipe_name, O_RDONLY);
    read(fd, buffer, sizeof(buffer));
    close(fd);

    printf("Process B: Received message from Process A: %s\n", buffer);

    return 0;
}
/*
Process B: Received message from Process A
*/