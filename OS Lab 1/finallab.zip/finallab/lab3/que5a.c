#include <stdio.h>
#include <unistd.h>

int main()
{
    int x = 42;

    printf("Process PID: %d, Variable 'x' Address: %p\n", getpid(), &x);

    while (1)
    {
        // Enter a long loop
    }

    return 0;
}
// output
/*
Process PID: 27432, Variable 'x' Address: 0061FECC
*/
