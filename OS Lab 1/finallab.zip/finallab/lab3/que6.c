#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <sys/types.h>
#include <unistd.h>

#define BUFFER_SIZE 256

int main()
{
    int pipefd[2]; // File descriptors for the pipe
    pid_t child_pid;

    // Create a pipe
    if (pipe(pipefd) == -1)
    {
        perror("pipe");
        exit(EXIT_FAILURE);
    }

    // Create a child process
    child_pid = fork();

    if (child_pid == -1)
    {
        perror("fork");
        exit(EXIT_FAILURE);
    }

    if (child_pid == 0)
    {
        // This is the child process
        close(pipefd[1]); // Close the write end of the pipe

        char buffer[BUFFER_SIZE];
        ssize_t bytes_read;

        printf("Child process is reading from the pipe:\n");

        while ((bytes_read = read(pipefd[0], buffer, BUFFER_SIZE)) > 0)
        {
            write(STDOUT_FILENO, buffer, bytes_read); // Print to the screen
        }

        close(pipefd[0]);
        printf("Child process finished reading.\n");
    }
    else
    {
        // This is the parent process
        close(pipefd[0]); // Close the read end of the pipe

        char *message = "Hello, Child! This is the parent process.\n";

        printf("Parent process is writing to the pipe:\n");

        // Write data to the pipe
        write(pipefd[1], message, strlen(message));

        close(pipefd[1]); // Close the write end of the pipe
        printf("Parent process finished writing.\n");
    }

    return 0;
}
// output
/*
Parent process is writing to the pipe:
Parent process finished writing.

*/
