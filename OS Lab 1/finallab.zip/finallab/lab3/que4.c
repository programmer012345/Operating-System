#include <stdio.h>
#include <stdlib.h>
#include <sys/types.h>
#include <sys/stat.h>
#include <fcntl.h>
#include <unistd.h>

int main()
{
    // Open a file for writing
    int fd = open("example.txt", O_WRONLY | O_CREAT | O_TRUNC, 0644);

    if (fd == -1)
    {
        perror("open");
        exit(EXIT_FAILURE);
    }

    pid_t child_pid = fork();

    if (child_pid == -1)
    {
        perror("fork");
        exit(EXIT_FAILURE);
    }

    if (child_pid == 0)
    {
        // This is the child process
        const char *child_message = "Child process writing to the file.\n";
        write(fd, child_message, strlen(child_message));
    }
    else
    {
        // This is the parent process
        const char *parent_message = "Parent process writing to the file.\n";
        write(fd, parent_message, strlen(parent_message));
    }

    close(fd);

    return 0;
}
