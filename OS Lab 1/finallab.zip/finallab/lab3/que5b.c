#include <stdio.h>
#include <stdlib.h>
#include <sys/types.h>
#include <unistd.h>

int main()
{
    int x = 42;

    pid_t child_pid = fork();

    if (child_pid == -1)
    {
        perror("fork");
        exit(EXIT_FAILURE);
    }

    if (child_pid == 0)
    {
        // This is the child process
        printf("Child Process (PID: %d): Variable 'x' Address: %p\n", getpid(), &x);

        while (1)
        {
            // Enter a long loop in the child
        }
    }
    else
    {
        // This is the parent process
        printf("Parent Process (PID: %d): Variable 'x' Address: %p\n", getpid(), &x);

        while (1)
        {
            // Enter a long loop in the parent
        }
    }

    return 0;
}
// output
/*
Parent Process (PID: 7008): Variable 'x' Address: 0x7ffd6574cea0
Child Process (PID: 7012): Variable 'x' Address: 0x7ffd6574cea0
^C
*/
