#include <stdio.h>
#include <stdlib.h>
#include <sys/types.h>
#include <sys/wait.h>
#include <unistd.h>

int main()
{
    pid_t child_pid;
    int status;

    // Create a child process
    child_pid = fork();

    if (child_pid == -1)
    {
        perror("fork");
        exit(EXIT_FAILURE);
    }

    if (child_pid == 0)
    {
        // This is the child process
        printf("Child process: My PID is %d\n", getpid());
        // Simulate some work in the child process
        sleep(2);
        // Exit the child process
        exit(EXIT_SUCCESS);
    }
    else
    {
        // This is the parent process
        printf("Parent process: My PID is %d\n", getpid());
        // Wait for the child to terminate and get its exit status
        wait(&status);

        if (WIFEXITED(status))
        {
            printf("Child process terminated normally with status: %d (0x%x)\n",
                   WEXITSTATUS(status), WEXITSTATUS(status));
        }
        else if (WIFSIGNALED(status))
        {
            printf("Child process terminated by signal %d (0x%x)\n",
                   WTERMSIG(status), WTERMSIG(status));
        }
    }

    return 0;
}
// output
/*
Parent process: My PID is 2662
Child process: My PID is 2666
Child process terminated normally with status: 0 (0x0)
*/
